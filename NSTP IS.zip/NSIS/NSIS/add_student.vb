﻿Imports System.Data.Sql
Imports System.Data.SqlClient
Imports System.Security.Cryptography.X509Certificates
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports MySql.Data.MySqlClient
Public Class add_student
    Dim constr As String = "server=localhost;port=3306;username=root;password=;database=nstp_admin"
    Dim conn As MySqlConnection = New MySqlConnection(constr)

    Dim con As MySqlConnection
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Adding()
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Adding()

        conn.Open()
        Dim comma As New MySqlCommand("INSERT INTO `stud_info`(`serial`, `lname`, `fname`, `mname`, `course`, `section`, `component`) VALUES (@serial,@lname,@fname,@mname,@course,@sec,@comp)", conn)

        comma.Parameters.Add("@serial", MySqlDbType.VarChar).Value = TextBox1.Text
        comma.Parameters.Add("@lname", MySqlDbType.VarChar).Value = TextBox2.Text
        comma.Parameters.Add("@fname", MySqlDbType.VarChar).Value = TextBox3.Text
        comma.Parameters.Add("@mname", MySqlDbType.VarChar).Value = TextBox4.Text
        comma.Parameters.Add("@course", MySqlDbType.VarChar).Value = TextBox5.Text
        comma.Parameters.Add("@sec", MySqlDbType.VarChar).Value = TextBox6.Text
        comma.Parameters.Add("@comp", MySqlDbType.VarChar).Value = TextBox7.Text


        If comma.ExecuteNonQuery() = 1 Then
            MessageBox.Show("Added")
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()
            TextBox5.Clear()
            TextBox6.Clear()
            TextBox7.Clear()
        Else
            MessageBox.Show("Error")

        End If

        conn.Close()

    End Sub

    Private Sub add_student_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class