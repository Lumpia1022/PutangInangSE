﻿Public Class admin_portal
    Sub switchPanel(panel As Form)
        Me.Refresh()
        Panel1.Controls.Clear()
        panel.TopLevel = False
        Panel1.Controls.Add(panel)
        panel.Show()
    End Sub
    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Form1.Show()
        Me.Close()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        switchPanel(admin_student)

    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs)
    End Sub

    Private Sub admin_portal_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class