﻿Imports System.Data.SqlClient
Imports System.Data.Sql
Imports MySql.Data.MySqlClient
Module Module1
    Public con As New MySqlConnection
    Public cmd As New MySqlCommand
    Public adp As New MySqlDataAdapter

    Sub conOpen()
        con.ConnectionString = "server=localhost;port=3306;username=root;password=;database=nstp_admin"
        con.Open()
    End Sub
End Module
