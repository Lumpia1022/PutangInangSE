﻿Imports NSIS.Form1
Public Class administration
    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged

        If CheckBox1.Checked = False Then
            TextBox2.PasswordChar = "*"
        Else
            TextBox2.PasswordChar = ""
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim Username As String
        Dim Password As String
        Username = TextBox1.Text
        Password = TextBox2.Text
        If (Username.Equals("admin") And Password.Equals("admin")) Then
            admin_portal.Show()
            Form1.Hide()
            TextBox1.Clear()
            TextBox2.Clear()
        Else
            MsgBox("Invalid Account", vbCritical, "Error")

        End If
    End Sub
End Class