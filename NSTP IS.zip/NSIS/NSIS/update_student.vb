﻿Imports System.Data.Sql
Imports System.Data.SqlClient
Imports System.Security.Cryptography.X509Certificates
Imports MySql.Data.MySqlClient
Public Class update_student
    Dim constr As String = "server=localhost;port=3306;username=root;password=;database=nstp_admin"
    Dim conn As MySqlConnection = New MySqlConnection(constr)
    Dim WithEvents refreshTimer As New Timer()


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Updates()
        refreshTimer.Interval = 5000
        refreshTimer.Start()
        Loadlist()
    End Sub


    Private Sub Updates()


        Dim query As String = "UPDATE stud_info SET lname=@lname, fname=@fname, mname=@mname, course=@course, section=@section WHERE serial=@serial"
        Dim update As New MySqlCommand(query, conn)


        update.Parameters.AddWithValue("@lname", TextBox3.Text)
        update.Parameters.AddWithValue("@fname", TextBox4.Text)
        update.Parameters.AddWithValue("@mname", TextBox5.Text)
        update.Parameters.AddWithValue("@course", TextBox6.Text)
        update.Parameters.AddWithValue("@section", TextBox7.Text)
        update.Parameters.AddWithValue("@serial", TextBox2.Text)

        Try
            conn.Open()
            Dim rowsAffected As Integer = update.ExecuteNonQuery()
            If rowsAffected > 0 Then
                MsgBox("Record updated successfully.")
                TextBox2.Clear()
                TextBox3.Clear()
                TextBox4.Clear()
                TextBox5.Clear()
                TextBox6.Clear()
                TextBox7.Clear()
            Else
                MsgBox("No record found with the given serial.")
            End If
        Catch ex As MySqlException
            MsgBox("An error occurred: " & ex.Message)
        Finally
            conn.Close()
        End Try


    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub


    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick


        If e.RowIndex >= 0 AndAlso e.ColumnIndex >= 0 Then
            Dim firstColumnIndex As Integer = 0
            Dim secondColumnIndex As Integer = 1
            Dim thirdColumnIndex As Integer = 2
            Dim fourthColumnIndex As Integer = 3
            Dim fifthColumnIndex As Integer = 4
            Dim sixthColumnIndex As Integer = 5


            Dim firstColumnValue As Object = DataGridView1.Rows(e.RowIndex).Cells(firstColumnIndex).Value
            Dim secondColumnValue As Object = DataGridView1.Rows(e.RowIndex).Cells(firstColumnIndex).Value
            Dim thirdColumnValue As Object = DataGridView1.Rows(e.RowIndex).Cells(firstColumnIndex).Value
            Dim fourthColumnValue As Object = DataGridView1.Rows(e.RowIndex).Cells(firstColumnIndex).Value
            Dim fifthColumnValue As Object = DataGridView1.Rows(e.RowIndex).Cells(firstColumnIndex).Value
            Dim sixthColumnValue As Object = DataGridView1.Rows(e.RowIndex).Cells(firstColumnIndex).Value

        End If
    End Sub


    Private Sub update_student_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Loadlist()
        dbconn()
    End Sub
    Private Sub refreshTimer_Tick(sender As Object, e As EventArgs) Handles refreshTimer.Tick
        Loadlist()
    End Sub

    Private Sub Loadlist()
        Try
            conn.Open()
            Dim query As String = "SELECT * FROM stud_info"
            Dim adapter As New MySqlDataAdapter(query, conn)
            Dim dataTable As New DataTable()
            adapter.Fill(dataTable)
            DataGridView1.DataSource = dataTable
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

End Class