﻿Imports System.Data.Sql
Imports System.Data.SqlClient
Imports System.Security.Cryptography.X509Certificates
Imports MySql.Data.MySqlClient

Public Class instructor_login
    Dim constr As String = "server=localhost;port=3306;username=root;password=;database=nstp_admin"
    Dim conn As MySqlConnection = New MySqlConnection(constr)
    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged

        If CheckBox1.Checked = False Then
            TextBox2.PasswordChar = "*"
        Else
            TextBox2.PasswordChar = ""
        End If
    End Sub

    Private Sub instructor_login_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click




        Dim query As String = "SELECT * FROM instructor_data WHERE Id = @username AND pass = @password"
        Dim inst As New MySqlCommand(query, conn)

        inst.Parameters.AddWithValue("@username", TextBox1.Text)
        inst.Parameters.AddWithValue("@password", TextBox2.Text)

        Try
            conn.Open()
            Dim reader As MySqlDataReader = inst.ExecuteReader()

            If reader.HasRows Then
                instructor_portal.Show()
                Me.Hide()
            Else
                MessageBox.Show("Invalid username or password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            reader.Close()
        Catch ex As Exception
            MessageBox.Show("An error occurred: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            conn.Close()
        End Try

    End Sub
End Class