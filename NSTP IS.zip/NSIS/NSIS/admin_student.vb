﻿Imports System.Data.Sql
Imports System.Data.SqlClient

Public Class admin_student
    Private connectionString As String = "server=localhost;port=3306;user=root;password=;database=nstp_admin"
    Sub switchPanel(panel As Form)
        Me.Refresh()
        Panel1.Controls.Clear()
        panel.TopLevel = False
        Panel1.Controls.Add(panel)
        panel.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        switchPanel(list_of_student)
    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        switchPanel(add_student)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        switchPanel(update_student)

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub admin_student_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class