﻿Imports System.Data.Sql
Imports System.Data.SqlClient
Imports System.Security.Cryptography.X509Certificates
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports MySql.Data.MySqlClient
Public Class update_grade
    Dim constr As String = "server=localhost;port=3306;username=root;password=;database=nstp_admin"
    Dim conn As MySqlConnection = New MySqlConnection(constr)
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

    End Sub

    Private Sub Updates()
        Dim query As String = "UPDATE stud_info SET grade = @grade WHERE serial = @serial"
        Dim update As New MySqlCommand(query, conn)

        update.Parameters.AddWithValue("@grade", TextBox3.Text)
        update.Parameters.AddWithValue("@serial", TextBox2.Text)

        Try
            conn.Open()
            Dim rowsAffected As Integer = update.ExecuteNonQuery()
            If rowsAffected > 0 Then
                MsgBox("Record updated successfully.")
                TextBox2.Clear()
                TextBox3.Clear()
            Else
                MsgBox("No record found with the given serial.")
            End If
        Catch ex As MySqlException
            MsgBox("An error occurred: " & ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

End Class