﻿Imports MySql.Data.MySqlClient

Public Class instructor_portal_listofstuds
    Dim constr As String = "server=localhost;port=3306;username=root;password=;database=nstp_admin"
    Dim conn As MySqlConnection = New MySqlConnection(constr)
    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        If e.RowIndex >= 0 AndAlso e.ColumnIndex >= 0 Then
            Dim firstColumnIndex As Integer = 0
            Dim secondColumnIndex As Integer = 1
            Dim thirdColumnIndex As Integer = 2
            Dim fourthColumnIndex As Integer = 3
            Dim fifthColumnIndex As Integer = 4
            Dim sixthColumnIndex As Integer = 5


            Dim firstColumnValue As Object = DataGridView1.Rows(e.RowIndex).Cells(firstColumnIndex).Value
            Dim secondColumnValue As Object = DataGridView1.Rows(e.RowIndex).Cells(firstColumnIndex).Value
            Dim thirdColumnValue As Object = DataGridView1.Rows(e.RowIndex).Cells(firstColumnIndex).Value
            Dim fourthColumnValue As Object = DataGridView1.Rows(e.RowIndex).Cells(firstColumnIndex).Value
            Dim fifthColumnValue As Object = DataGridView1.Rows(e.RowIndex).Cells(firstColumnIndex).Value
            Dim sixthColumnValue As Object = DataGridView1.Rows(e.RowIndex).Cells(firstColumnIndex).Value

        End If
    End Sub
    Private Sub Loadlist()
        Try
            conn.Open()
            Dim query As String = "SELECT * FROM stud_info"
            Dim adapter As New MySqlDataAdapter(query, conn)
            Dim dataTable As New DataTable()
            adapter.Fill(dataTable)
            DataGridView1.DataSource = dataTable
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub instructor_portal_listofstuds_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Loadlist()
    End Sub
End Class