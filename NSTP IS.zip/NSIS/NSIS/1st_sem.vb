﻿Public Class _1st_sem
    Sub switchPanel(panel As Form)
        Me.Refresh()
        Panel1.Controls.Clear()
        panel.TopLevel = False
        Panel1.Controls.Add(panel)
        panel.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        switchPanel(add_grade)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        switchPanel(update_grade)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) 

    End Sub

    Private Sub _1st_sem_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class