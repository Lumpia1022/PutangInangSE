﻿Imports MySql.Data.MySqlClient

Module Module2

    Function dbconn() As MySqlConnection
        dbconn = New MySqlConnection("server=localhost; username=root; password=; database=nstp_admin")


        Try
            dbconn.Open()
        Catch ex As Exception
            MsgBox("failed")
        End Try
    End Function

End Module
